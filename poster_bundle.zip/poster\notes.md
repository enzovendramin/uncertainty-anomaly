# Is model uncertainty a measure of anomaly? — poster notes

Code: github.com/enzovendramin/uncertainty-anomaly · commit ec1a372 · every number below comes from a script in `src/`.
Data: 100 representative MacrOData datasets (50 OddBench + 50 OvRBench), development set. All scores are compared on the same rows. One seed unless stated.

## The question, in one paragraph

A fraud is something the model has never seen. So when a model is *unsure* about a row, is that row more likely to be an anomaly?
And can those alerts carry a guarantee on the number of false alarms? We test this on 100 anomaly-detection datasets
where the training data contain only normal rows: each model predicts every column from the other columns, and we read two
things from its answer — its **uncertainty** (how wide the answer is, never looking at the true value) and its **error**
(how surprising the true value was). A plain **kNN distance** to the nearest normal rows is the baseline.

## Method (fig1_pipeline)

normal rows → predict each column → uncertainty / error score → conformal p-value (compare with known-normal rows)
→ e-value (a bet against "normal") → e-BH (cut the ranked list so that false alarms stay under 10%).
Metric for ranking: AUROC = probability that a random anomaly scores above a random normal row (0.5 = chance).

## Thesis sentence

*A model's uncertainty is an anomaly score exactly to the extent that it measures distance from the training data;
none of the models beats measuring distance directly, and the guaranteed-alert machinery works but is limited by the score, not by the statistics.*

## Panel Q1 — TabPFN (fig2, fig4)

Verdict: yes, weakly, and only with the right measure. TabPFN's regression uncertainty ranks anomalies above normal rows
with AUROC 0.655 (below chance on 23% of datasets); its error 0.72; kNN 0.754.
The first attempt, with columns cut into 10 bins, scored 0.453 — inverted on 57% of datasets — because
binning throws away "how far outside the normal range"; removing the bins improved 76 of 99 datasets by +0.202.
Caption for the ECG example: anomalous heartbeats are extreme in every column at once; with bins the model is confidently right
about each column (AUROC 0.134), without bins its spread explodes far from the data (0.937); kNN 0.989.

## Panel Q1 across models (fig3)

Gaussian process uncertainty 0.716 · TabPFN disagreement between 4 copies 0.686 · TabPFN single-copy width 0.655
· CatBoost knowledge uncertainty 0.632 · kNN 0.754. Reading: uncertainty works when it is about distance
(the GP's is, by construction, and it correlates 0.85 with kNN across datasets); trees extrapolate flat and do not know when they
are lost; the foundation model sits in between, and measuring disagreement helps only a little (48/100 wins over width).
Error-type scores land at ~0.72 for every model family.

## Panel: what each score sees (fig5)

Synthetic data with four planted anomaly kinds. Distance-type uncertainty (GP, TabPFN disagreement, kNN) sees extreme values,
whole-row shifts and unusual-but-consistent rows (subspace) at 0.98–0.95 but is weaker on broken relationships (0.81).
Error scores are the best on broken relationships (0.93) and nearly blind to subspace anomalies (0.55).
CatBoost's knowledge uncertainty is the weakest on extreme values and shifts (0.85, 0.81).

## Panel Q2 — review budget (fig6)

Reviewing the top 5% of rows: kNN fills the list with 47% real anomalies, TabPFN uncertainty 37%,
TabPFN error 42%, kNN + error 49% (random list: 16%).
Uncertainty beats kNN on 28/85 datasets. Adding uncertainty to kNN does not help; adding error helps slightly (not significant).
Combinations merge scores first (mean of −log p) and calibrate once.

## Panel Q3 — guarantees (fig7)

Pooling all alerts across datasets, false alarms are 7% (kNN), 8% (uncertainty), 7% (error) against 10% promised — the guarantee holds.
But the list is empty on 75% of datasets for kNN (84% for uncertainty): e-BH flags nothing rather than break the promise.
Feeding the data in batches of 200 rows raises datasets-with-alerts to 45% (kNN) with false alarms still at 8%.
Power needs at least ~300 calibration rows. Single-split alert lists overlap only 29% (uncertainty) to 56% (kNN) between random splits;
averaging e-values over 3 splits keeps the guarantee but halves the number of alerts.

## Panel: fraud, payments and security datasets (table fraud_subset_auroc)

8 datasets: kNN 0.83, GP uncertainty 0.844, TabPFN disagreement 0.804,
TabPFN width 0.796, CatBoost knowledge 0.734, TabPFN error 0.799.

## Caveats (say them on the poster)

- 100 development datasets, one seed for most panels (three for the derandomisation part); the 1,346 public datasets were not run.
- 18% of datasets have >10% duplicate training rows, which favours distance scores; excluding the 8 datasets with >50% duplicates changes means by ≤0.02 (table duplicates_sensitivity).
- Column-prediction budget: up to 10 target columns and 1000 context rows per dataset; tests subsampled to 4000 rows.
- Related work: a pilot by Eduardo on 10 OddBench datasets uses reconstruction *error* with five models; this study is the uncertainty and guarantee side.

## References

Angelopoulos & Bates 2021 · Bates, Candès, Lei, Romano, Sesia 2023 · Ren & Barber 2023 · Vovk & Wang 2021 · Wang & Ramdas 2022 ·
De Melo Costa et al. 2026 (HPLR) · Ding et al. 2026 (macrOData) · Hollmann et al. 2023/2025 (TabPFN).
